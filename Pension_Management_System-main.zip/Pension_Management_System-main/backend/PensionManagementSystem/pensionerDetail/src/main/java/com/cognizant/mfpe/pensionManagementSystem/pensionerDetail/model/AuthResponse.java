package com.cognizant.mfpe.pensionManagementSystem.pensionerDetail.model;

public class AuthResponse {
	// User id
	private String uid;
	// Username
	private String name;
	// is Token valid
	private boolean isValid;
}
