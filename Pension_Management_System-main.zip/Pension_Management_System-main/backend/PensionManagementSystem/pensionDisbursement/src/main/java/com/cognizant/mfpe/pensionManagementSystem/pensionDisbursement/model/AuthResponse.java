package com.cognizant.mfpe.pensionManagementSystem.pensionDisbursement.model;

public class AuthResponse {
	// User Id
	private String uid;
	//Username
	private String name;
	//Is Token valid
	private boolean isValid;
}
